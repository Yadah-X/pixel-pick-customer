# Pixel Pick Admin
Admin dashboard prototype. It has no authentication and contains demo figures only; do not use for real customer data.
