# Pixel Pick Prototype

This package has two separate static sites:
- `pixel-pick-customer` — customer-facing prototype
- `pixel-pick-admin` — admin dashboard prototype

## Deploying on Render
Create a separate GitHub repository for each folder, then create a Render **Static Site** for each repository.
For each site:
- Branch: `main`
- Build Command: leave blank
- Publish Directory: `.`

Render assigns a separate `onrender.com` URL after each deployment. Official guide: https://render.com/docs/your-first-deploy

## Important
These are visual/demo prototypes only. There is no database, real account/login security, payment processing, entry validation, prize fulfilment, or winner audit system. Do not accept money or real customer data until those systems and South African legal compliance have been implemented and reviewed.
